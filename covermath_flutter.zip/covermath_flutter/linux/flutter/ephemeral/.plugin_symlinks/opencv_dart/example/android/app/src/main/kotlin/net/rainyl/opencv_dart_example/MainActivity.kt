package net.rainyl.opencv_dart_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
