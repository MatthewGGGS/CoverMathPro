package net.rainyl.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
